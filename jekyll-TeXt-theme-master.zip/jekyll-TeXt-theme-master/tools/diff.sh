Diffmerge ./_config.yml ./docs/_config.yml ./docs/_config.dev.yml
Diffmerge ./_config.yml ./test/_config.yml

Diffmerge ./_data/ ./docs/_data/
Diffmerge ./_data/ ./test/_data
